package com.aporello.HealthyAvatar.android;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    private WebView webView;
    private boolean out;
    private Cursor cursor;
    private LocalStorage localStorage;
    private static String URL_NAME = "http://lavarel5-n1ck0g0m3z.c9users.io/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        localStorage = new LocalStorage(this);
        cursor = localStorage.getUsers();

        webView = (WebView) findViewById(R.id.activity_main_webview);

        if(cursor.getCount()==0){
            webView.loadUrl(URL_NAME+"login");
        }

        if(cursor.getCount()!=0 && localStorage.getCategory().contains("1")){
            Intent intent = new Intent().setClass(LoginActivity.this,MenuFragmentTestActivity.class);
            startActivity(intent);
        }
        if(cursor.getCount()!=0 && localStorage.getCategory().contains("2")){
            Intent intent = new Intent().setClass(LoginActivity.this,MealEvaluateActivity.class);
            startActivity(intent);
        }


        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                if(url.contains("http://lavarel5-n1ck0g0m3z.c9users.io/") && out==true){
                    view.loadUrl("http://lavarel5-n1ck0g0m3z.c9users.io/logout");
                    out = false;
                }
                if(url.contains("http://lavarel5-n1ck0g0m3z.c9users.io/articles")){
                    Intent intent = new Intent().setClass(LoginActivity.this,MenuFragmentTestActivity.class);
                    startActivity(intent);
                }
                if(url.contains("http://lavarel5-n1ck0g0m3z.c9users.io/image/create")){
                    Intent intent = new Intent().setClass(LoginActivity.this,MealEvaluateActivity.class);
                     startActivity(intent);
                }
            }
        });

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setSupportMultipleWindows(true);
        webView.setWebChromeClient(new WebChromeClient());
    }

}
