package com.aporello.HealthyAvatar.android;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionSet;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yuki on 16/08/09.
 */
public class MenuFragmentTestActivity extends AppCompatActivity{
    private final static String TAG = MenuFragmentTestActivity.class.getSimpleName();

    private final int REQUEST_WRITE_EXTRA_STORAGE = 1000;
    private final int REQUEST_CAMERA = 2000;
    private final String FRAGMENT_MENU = "menu_fragment";
    private Uri m_uri;

    int avatarFlag = 0;
    @BindView(R.id.image_view_avatar) public ImageView imageViewAvatar;
    @OnClick(R.id.image_view_avatar)
    public void avatarClick(){
        switch(avatarFlag){
            case 0:
                imageViewAvatar.setImageDrawable(getResources().getDrawable(R.drawable.avatar2));
                avatarFlag++;
                break;

            case 1:
                imageViewAvatar.setImageDrawable(getResources().getDrawable(R.drawable.avatar3));
                avatarFlag++;
                break;

            case 2:
                imageViewAvatar.setImageDrawable(getResources().getDrawable(R.drawable.avatar1));
                avatarFlag = 0;
                break;
        }
    }

    int avatarBackFlag = 0;
    @BindView(R.id.image_view_avatar_back) public ImageView imageViewAvatarBack;
    @OnClick(R.id.image_view_avatar_back)
    public void avatarBackClick(){
        switch(avatarBackFlag){
            case 0:
                imageViewAvatarBack.setImageDrawable(getResources().getDrawable(R.drawable.back2));
                avatarBackFlag++;
                break;

            case 1:
                imageViewAvatarBack.setImageDrawable(getResources().getDrawable(R.drawable.back1));
                avatarBackFlag = 0;
                break;
        }
    }

    @BindView(R.id.container) public FrameLayout container;
    @BindView(R.id.image_view) public ImageView imageView;
    @OnClick(R.id.button_camera)
    public void clickedCameraButton(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if(!(checkSelfPermission(Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED)){
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA},  REQUEST_WRITE_EXTRA_STORAGE);
            } else {
                startCamera();
            }
        }else{
            startCamera();
        }
    }
    @OnClick(R.id.image_view)
    public void clickedImageView(){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();

        Fragment f = manager.findFragmentByTag(FRAGMENT_MENU);
        if(f == null){
            f = MenuFragment.getInstance();
            transaction.replace(R.id.container, f, FRAGMENT_MENU);
            rotateXButton(true);
        }else{
            transaction.remove(f);
            rotateXButton(false);
        }

        transaction.commit();
    }
    @OnClick(R.id.button)
    public void cli(){
        startActivity(new Intent(this, ScreenShotActivity.class));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        initView();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        }else{
            Toast.makeText(this
                    ,"カメラを許可してください"
                    , Toast.LENGTH_SHORT).show();
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CAMERA){
            if(resultCode != RESULT_OK) {
                // キャンセル時
                return ;
            }

            // ギャラリーへスキャンを促す
            MediaScannerConnection.scanFile(
                    this,
                    new String[]{m_uri.getPath()},
                    new String[]{"image/jpeg"},
                    null
            );

            Intent intent = new Intent(this, CheckPhotoActivity.class);
            intent.putExtra("uri", m_uri.toString());
            startActivity(intent);
        }
    }

    private void initView(){
        setContentView(R.layout.acitivity_menu_test);
        ButterKnife.bind(this);

    }

    @TargetApi(11)
    private void rotateXButton(boolean reverse){
        ViewGroup.LayoutParams params = imageView.getLayoutParams();
        float x = params.width;
        float y = params.height;

        int rotateFrom;
        int rotateTo;
        if(reverse){
            rotateFrom = 0;
            rotateTo = 45;
        }else{
            rotateFrom = 45;
            rotateTo = 0;
        }

        Animation anime = new RotateAnimation(rotateFrom, rotateTo, x / 2, y / 2);
        anime.setFillAfter(true);
        anime.setDuration(100);
        imageView.startAnimation(anime);
    }

    private void startCamera(){
        String photoName = System.currentTimeMillis() + ".jpg";
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE, photoName);
        contentValues.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        m_uri = getContentResolver()
                .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intentCamera.putExtra(MediaStore.EXTRA_OUTPUT, m_uri);
        startActivityForResult(intentCamera, REQUEST_CAMERA);
    }
}
