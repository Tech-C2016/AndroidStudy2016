package com.aporello.HealthyAvatar.android.network;

import android.annotation.TargetApi;
import android.util.Log;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * HTTP通信用Utilクラス
 */
public class HttpUtils{
    /**
     * Log出力タグ.
     */
    private static final String TAG = HttpUtils.class.getSimpleName();

    /**
     * SharedPreferenceインスタンス.
     */

    /**
     * リクエストURL.
     */
    private static final String REQUEST_URL
            = "https://api.apigw.smt.docomo.ne.jp/imageRecognition/v1/concept/classify/";

    /**
     * API Key.
     */
    private static final String APIKEY = "";

    /**
     * BOUNDARY.
     */
    private static final String BOUNDARY
            = "---------------------------" + System.currentTimeMillis() + "--";

    /**
     * 改行.
     */
    private static final String NEW_LINE = "\r\n";

    /**
     * タイムアウト時間(msec).
     */
    private static final long PROCESS_TIMEOUT = 30000;

    /**
     * HTTPリクエストプロパティ フィールド.
     */
    private static final String REQUEST_PROPERTY_FIELD = "Content-Type";

    /**
     * HTTPリクエストプロパティ バリュー.
     */
    private static final String REQUEST_PROPERTY_VALUE
            = "multipart/form-data; boundary=" + BOUNDARY;

    /**
     * HTTPリクエスト モデル名ヘッダー.
     */
    private static final String REQUEST_MODEL_NAME_HEADER
            = "Content-Disposition: form-data; name=\"modelName\"" + NEW_LINE + NEW_LINE;

    /**
     * HTTPリクエスト 画像ヘッダー.
     */
    private static final String REQUEST_IMAGE_HEADER_FORMAT
            = "Content-Disposition: form-data; name=\"image\"; filename=\"%s\"" + NEW_LINE
            + "Content-Type: image/jpeg" + NEW_LINE + NEW_LINE;

    /**
     * HTTPリクエストメソッド(POST).
     */
    private static final String REQUEST_METHOD_POST = "POST";

    /**
     * HTTPレスポンスコード(成功).
     */
    private static final int RESPONSE_CODE_SUCCESS = 200;

    /**
     * コンストラクタ.
     */
    public HttpUtils() {
    }

    /**
     * 画像認識サーバへのPOSTリクエスト(画像データ送付).
     *
     * @param imageFile サーバに送信する画像ファイル
     * @return 画像認識結果のJSONファイルを返す
     * @throws IOException HTTP通信,またはファイル読み書き時にエラーが発生した場合
     */
    public AnalysisResultJson postImageFileRecognitionRequest(File imageFile) throws IOException{

        // AnalysisResultJson定義
        AnalysisResultJson result = null;

        // HttpURLConnection定義
        HttpURLConnection connection = null;

        try {
            // URL取得
            URL url = new URL(REQUEST_URL + buildGetParams());
            // HttpURLConnection作成
            connection = (HttpURLConnection) url.openConnection();

            // リクエストボディ作成
            byte[] requestBody = createRequestBody(imageFile.getAbsolutePath());

            // HttpURLConnection設定
            connection.setConnectTimeout((int) PROCESS_TIMEOUT);
            connection.setReadTimeout((int) PROCESS_TIMEOUT);
            connection.setRequestProperty(REQUEST_PROPERTY_FIELD, REQUEST_PROPERTY_VALUE);
            connection.setRequestMethod(REQUEST_METHOD_POST);
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(requestBody.length);

            // リクエスト送信
            sendRequest(connection, requestBody);

            // レスポンスコード確認
            int responseCode = connection.getResponseCode();
            Log.d(TAG, "ResponseCode : " + responseCode);
            if (responseCode != RESPONSE_CODE_SUCCESS) {
                throw new IOException();
            }

            // レスポンスボディ取得
            String resBody = getResponseBody(connection);
            Log.d(TAG, "ResponseBody : " + resBody);

            try {
                result = new AnalysisResultJson(resBody);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();

            throw new IOException();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return result;
    }

    /**
     * リクエストボディの作成.
     *
     * @param filePath 画像ファイルのパス
     * @return リクエストボディを返す
     * @throws IOException ファイル読み書き時にエラーが発生した場合
     */
    @TargetApi(20)
    private byte[] createRequestBody(String filePath) throws IOException{
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos.write(("--" + BOUNDARY + NEW_LINE).getBytes());

            // モデル名
            baos.write((REQUEST_MODEL_NAME_HEADER).getBytes());
            baos.write(("food" + NEW_LINE).getBytes());

            baos.write(("--" + BOUNDARY + NEW_LINE).getBytes());

            // 画像
            File imageFile = new File(filePath);
            Log.d("--------", filePath);
            baos.write((String.format(REQUEST_IMAGE_HEADER_FORMAT, imageFile.getName()))
                    .getBytes());
            baos.write(ImageUtils.getByteDataFromImage(filePath));
            baos.write((NEW_LINE).getBytes());

            baos.write(("--" + BOUNDARY + "--" + NEW_LINE).getBytes());
            return baos.toByteArray();
        } catch (IOException e) {
            throw new IOException(e);
        } finally {
            baos.close();
        }
    }

    /**
     * リクエストの送信.
     *
     * @param conn HTTP通信用コネクション
     * @param data multipart/form-data形式のリクエストパラメータ
     * @throws IOException ファイル書き込み時にエラーが発生した場合
     */
    @TargetApi(20)
    private static void sendRequest(HttpURLConnection conn, byte[] data) throws IOException{
        OutputStream os = conn.getOutputStream();
        try {
            os.write(data);
            os.flush();
        } catch (IOException e) {
            throw new IOException(e);
        } finally {
            os.close();
        }
    }

    /**
     * レスポンスボディ取得.
     *
     * @param conn HTTP通信用コネクション
     * @return 受信データ
     * @throws IOException ファイルの入出力時にエラーが発生した場合
     */
    @TargetApi(20)
    private String getResponseBody(HttpURLConnection conn) throws IOException{
        // レスポンスを取得する
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            InputStream is = conn.getInputStream();
            try {
                byte[] buf = new byte[1024];
                int size;
                while ((size = is.read(buf)) != -1) {
                    baos.write(buf, 0, size);
                }
            } catch (IOException e) {
                throw new IOException(e);
            } finally {
                is.close();
            }
            return new String(baos.toByteArray());
        } catch (IOException e) {
            throw new IOException(e);
        } finally {
            baos.close();
        }
    }


    /**
     * APIKEYを含むGETパラメータの構築.
     *
     * @return GETパラメータ用文字列を返す
     */
    private static String buildGetParams() {
        return APIKEY.length() > 0 ? "?APIKEY=" + APIKEY : "";
    }
}
