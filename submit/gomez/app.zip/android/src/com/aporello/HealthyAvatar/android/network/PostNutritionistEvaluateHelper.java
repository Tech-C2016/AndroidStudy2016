package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.util.Log;

import com.aporello.HealthyAvatar.android.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by yuki on 16/08/09.
 */
public class PostNutritionistEvaluateHelper implements LoaderManager.LoaderCallbacks<String>{
    private final static String TAG = PostNutritionistEvaluateHelper.class.getSimpleName();

    private final static String EXTRA_URL = "url";
    private final static String EXTRA_BODY = "body";

    private Context context;

    public PostNutritionistEvaluateHelper(Context context){
        this.context = context;
    }

    public void execute(String user, String password, String body){
        Bundle args = new Bundle();
        args.putString(EXTRA_URL, convertUrl(user, password));
        args.putString(EXTRA_BODY, body);

        ((FragmentActivity)context).getSupportLoaderManager().restartLoader(0, args, this);
    }

    private String convertUrl(String user, String password){
        return Utils.BASE_URL + "/" + user + "/" + Utils.convertSHA256(password);
    }

    @Override
    public Loader<String> onCreateLoader(int i, Bundle bundle){
        final String url = bundle.getString(EXTRA_URL);
        final String body = bundle.getString(EXTRA_BODY);
        AsyncTaskLoader asyncTaskLoader = new PostAsyncTaskLoader(context, url, body);
        asyncTaskLoader.forceLoad();
        return asyncTaskLoader;
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String s){
        String message;
        if(s != null){
            message = s;
        }else{
            message = "s is null";
        }
        Log.d(TAG, message);
    }

    @Override
    public void onLoaderReset(Loader<String> loader){

    }
}
