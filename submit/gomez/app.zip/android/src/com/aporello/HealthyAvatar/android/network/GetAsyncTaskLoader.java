package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by yuki on 16/08/07.
 */
public class GetAsyncTaskLoader extends AsyncTaskLoader<String>{
    private final static String TAG = GetAsyncTaskLoader.class.getSimpleName();

    private final String url;

    public GetAsyncTaskLoader(Context context, String url){
        super(context);
        this.url = url;
        Log.d(TAG, url);
    }

    @Override
    public String loadInBackground(){
        StringBuilder stringBuilder = new StringBuilder();

        try{
            URL url = new URL(this.url);
            HttpURLConnection connection
                    = (HttpURLConnection)url.openConnection();

            connection.connect();

            InputStream inputStream = connection.getInputStream();
            BufferedReader bufferedReader
                    = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while((line = bufferedReader.readLine()) != null){
                stringBuilder.append(line);
            }

        }catch(MalformedURLException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }

        return stringBuilder.toString();
    }
}
