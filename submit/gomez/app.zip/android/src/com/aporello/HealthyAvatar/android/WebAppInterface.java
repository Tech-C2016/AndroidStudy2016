package com.aporello.HealthyAvatar.android;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 * Created by N1cK0 on 16/08/09.
 */
public class WebAppInterface {

    Context mContext;

    private LocalStorage localStorage;

    public WebAppInterface(Context mContext){ this.mContext = mContext;}

    @JavascriptInterface
    public void logIn(String email, String password){
        localStorage = new LocalStorage(mContext);
        localStorage.insertUser(password,email);
    }

    @JavascriptInterface
    public void category(String name, String cate){
        int i = Integer.valueOf(cate);
        localStorage = new LocalStorage(mContext);
        localStorage.modifyUser(i, name);
        //Toast.makeText(mContext, name +" "+cate, Toast.LENGTH_SHORT).show();
    }

    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }
}
