package com.aporello.HealthyAvatar.android;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by yuki on 16/08/09.
 */
public class Utils{
    private final static String TAG = Utils.class.getSimpleName();

    public final static String BASE_URL = "http://lavarel5-n1ck0g0m3z.c9users.io/review";
    public final static String EXTRA_URL = "url";
    public final static String EXTRA_BODY = "body";

    public static String convertSHA256(String text) {

        // 変数初期化
        MessageDigest md = null;
        StringBuffer buffer = new StringBuffer();

        try {
            // メッセージダイジェストインスタンス取得
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            // 例外発生時、エラーメッセージ出力
        }

        // メッセージダイジェスト更新
        md.update(text.getBytes());

        // ハッシュ値を格納
        byte[] valueArray = md.digest();

        // ハッシュ値の配列をループ
        for(int i = 0; i < valueArray.length; i++){
            // 値の符号を反転させ、16進数に変換
            String tmpStr = Integer.toHexString(valueArray[i] & 0xff);

            if(tmpStr.length() == 1){
                // 値が一桁だった場合、先頭に0を追加し、バッファに追加
                buffer.append('0').append(tmpStr);
            } else {
                // その他の場合、バッファに追加
                buffer.append(tmpStr);
            }
        }

        // 完了したハッシュ計算値を返却
        return buffer.toString();
    }
}
