package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 画像処理用Utilクラス.
 */
public class ImageUtils{

    /**
     * 指定した角度で回転したBitmapを取得.
     *
     * @param origin   入力Bitmap
     * @param rotation 回転角度
     * @return 回転したBitmapオブジェクトを返す
     */
    public static Bitmap createRotateBitmap(Bitmap origin, int rotation) {
        // 画像回転
        if (rotation != 0) {
            // 回転Matrix
            Matrix rotate = new Matrix();
            rotate.postRotate(rotation);

            return Bitmap.createBitmap(origin, 0, 0,
                    origin.getWidth(), origin.getHeight(), rotate, true);
        } else {
            return origin.copy(origin.getConfig(), true);
        }
    }

    /**
     * BitmapにExif情報を付与し、JPEG画像として出力.
     *
     * @param image  入力Bitmap
     * @param output 出力先ファイル
     * @throws IOException 出力先ファイルが存在しない,またはEXIF情報の書き込みでエラーが発生した場合
     */
    public static void compressJpegAddExif(Bitmap image, File output) throws IOException{
        // Image書き出し
        FileOutputStream fos = new FileOutputStream(output);
        image.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        fos.flush();
        fos.close();

        // Exifに回転情報書き出し
        ExifInterface ei = new ExifInterface(output.getAbsolutePath());
        ei.setAttribute(ExifInterface.TAG_ORIENTATION,
                Integer.toString(ExifInterface.ORIENTATION_NORMAL));
        ei.saveAttributes();
    }

    /**
     * 画像ファイルのURIから回転角度を取得.
     *
     * @param uri     画像ファイルのURI
     * @param context コンテキスト
     * @return 画像ファイルの回転角度
     */
    public static int getRotationFromUri(Uri uri, Context context) {

        if (Build.VERSION.SDK_INT < 19) {
            Cursor cursor = context.getContentResolver().query(
                    uri,
                    new String[]{MediaStore.Images.ImageColumns.ORIENTATION},
                    null, null, null);
            cursor.moveToFirst();
            int orientation = cursor.getInt(0);
            cursor.close();

            return orientation;
        } else {
            // URI から"image:xxxx"部分を取得
            String wholeId = DocumentsContract.getDocumentId(uri);
            // ":" で分割した2要素目("xxxx部分)を取得
            String id = wholeId.split(":")[1];
            // 検索対象のcolumnを設定
            String[] column = {MediaStore.Images.ImageColumns.ORIENTATION};
            // queryメソッドのselectionを設定
            String sel = MediaStore.Images.Media._ID + "=?";

            // cursorの取得
            Cursor cursor = context.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    column,
                    sel,
                    new String[]{id},
                    null
            );

            cursor.moveToFirst();
            int orientation = cursor.getInt(0);
            cursor.close();

            return orientation;
        }
    }

    /**
     * 画像ファイルの情報をbyte配列で取得.
     *
     * @param filePath 画像ファイルパス
     * @return 画像情報のbyte配列を返す
     */
    public static byte[] getByteDataFromImage(String filePath) {
        try {
            FileInputStream fis = new FileInputStream(filePath);
            byte[] bytes = new byte[fis.available()];
            fis.read(bytes);
            return bytes;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new byte[0];
    }
}
