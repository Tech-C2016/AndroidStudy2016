package com.aporello.HealthyAvatar.android;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.aporello.HealthyAvatar.android.network.GetHealthDataHelper;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by yuki on 16/08/09.
 */
public class HealthScoreActivity extends AppCompatActivity{
    private final static String TAG = HealthScoreActivity.class.getSimpleName();

    @BindView(R.id.line_chart) public LineChart lineChart;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        initView();
    }

    @Override
    protected void onResume(){
        super.onResume();
        GetHealthDataHelper helper = new GetHealthDataHelper(this);
        helper.execute("user", "password");
    }

    private void initView(){
        setContentView(R.layout.activity_health_data);
        ButterKnife.bind(this);

        initChart();
    }

    private void initChart(){
        lineChart.setDescription("");

        lineChart.getAxisRight().setEnabled(false);
        lineChart.getAxisLeft().setEnabled(true);
        lineChart.setEnabled(true);

        lineChart.setPinchZoom(true);
        lineChart.setDoubleTapToZoomEnabled(true);
        lineChart.setGridBackgroundColor(0);

        lineChart.setScaleEnabled(true);

        //X軸周り
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setDrawLabels(true);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        xAxis.setSpaceBetweenLabels(0);

        lineChart.setData(createBarChartData());

        lineChart.invalidate();
        // アニメーション
        lineChart.animateY(2000, Easing.EasingOption.EaseInBack);
    }

    private LineData createBarChartData() {
        ArrayList<LineDataSet> lineDataSets = new ArrayList<>();

        // X軸
        ArrayList<String> xValues = new ArrayList<>();
        xValues.add("8/4");
        xValues.add("8/5");
        xValues.add("8/6");
        xValues.add("8/7");
        xValues.add("8/8");
        xValues.add("8/9");

        // valueA
        ArrayList<Entry> valuesA = new ArrayList<>();
        valuesA.add(new Entry(50, 0));
        valuesA.add(new Entry(60, 1));
        valuesA.add(new Entry(90, 2));
        valuesA.add(new Entry(100, 3));
        valuesA.add(new Entry(20, 4));
        valuesA.add(new Entry(60, 5));

        LineDataSet valuesADataSet = new LineDataSet(valuesA, "健康度グラフ");
        valuesADataSet.setColor(ColorTemplate.COLORFUL_COLORS[3]);

        lineDataSets.add(valuesADataSet);

        return new LineData(xValues, lineDataSets);
    }
}
