package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.util.Log;

import com.aporello.HealthyAvatar.android.Utils;

import org.apache.http.conn.ConnectTimeoutException;

/**
 * Created by yuki on 16/08/09.
 */
public class GetHealthDataHelper implements LoaderManager.LoaderCallbacks<String>{
    private final static String TAG = GetHealthDataHelper.class.getSimpleName();

    private Context context;

    public GetHealthDataHelper(Context context){
        this.context = context;
    }

    public void execute(String user, String password){
        Bundle args = new Bundle();
        args.putString(Utils.EXTRA_URL, convertUrl(user, password));
        ((FragmentActivity)context).getSupportLoaderManager().restartLoader(0, args, this);
    }

    private String convertUrl(String user, String password){
        return Utils.BASE_URL + "/" + user + "/" + Utils.convertSHA256(password);
    }

    @Override
    public Loader<String> onCreateLoader(int id, Bundle args){
        final String url = args.getString(Utils.EXTRA_URL);
        AsyncTaskLoader asyncTaskLoader = new GetAsyncTaskLoader(context, url);
        asyncTaskLoader.forceLoad();
        return asyncTaskLoader;
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data){
        if(data != null) Log.d(TAG, data);
    }

    @Override
    public void onLoaderReset(Loader<String> loader){}
}
