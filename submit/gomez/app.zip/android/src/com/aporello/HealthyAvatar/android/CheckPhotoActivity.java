package com.aporello.HealthyAvatar.android;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.widget.ImageView;

import com.aporello.HealthyAvatar.android.network.HttpUtils;
import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yuki on 16/08/10.
 */
public class CheckPhotoActivity extends AppCompatActivity{
    private final static String TAG = CheckPhotoActivity.class.getSimpleName();

    @BindView(R.id.imageView) public ImageView imageView;

    @OnClick(R.id.image_view_home)
    public void c(){
        startActivity(new Intent(this, MenuFragmentTestActivity.class));
        finish();
    }

    @OnClick(R.id.image_view_ok)
    public void cc(){
        startActivity(new Intent(this, MenuFragmentTestActivity.class));
        finish();
    }



    private int height = 10;
    private int width = 10;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_test);
        ButterKnife.bind(this);

        Intent intent = getIntent();
        Uri uri = null;
        if(intent != null){
            uri = Uri.parse(intent.getStringExtra("uri"));
        }

        //imageView.setImageURI(uri);
        //post(intent.getStringExtra("uri"));
    }

    private void post(String uri){
//        PostPhotoHelper helper = new PostPhotoHelper(this);
//            helper.execute("https://api.apigw.smt.docomo.ne.jp/imageRecognition/v1/concept/classify/" +
//                            "?APIKEY=784e434d76333635425930436e76514a7462725343426669555269617753754c50367a535a7338516f7730",
//                    getBody(uri));

        new Async(this, uri).forceLoad();
    }

    public class Async extends AsyncTaskLoader<String>{
        private String uri;
        public Async(Context context, String uri){
            super(context);
            this.uri = uri;
        }

        @Override
        public String loadInBackground(){
            HttpUtils utils = new HttpUtils();
            try{
                utils.postImageFileRecognitionRequest(new File(Uri.parse(uri).getPath()));
            }catch(IOException e){
                e.printStackTrace();
            }
            return null;
        }
    }

    private static final String BOUNDARY
            = "---------------------------" + System.currentTimeMillis() + "--";
    private static final String NEW_LINE = "\r\n";
    private static final String REQUEST_IMAGE_HEADER_FORMAT
            = "Content-Disposition: form-data; name=\"image\"; filename=\"%s\"" + NEW_LINE
            + "Content-Type: image/jpeg" + NEW_LINE + NEW_LINE;
    private static final String REQUEST_MODEL_NAME_HEADER
            = "Content-Disposition: form-data; name=\"modelName\"" + NEW_LINE + NEW_LINE;

    private byte[] createRequestBody(Uri uri) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos.write(("--" + BOUNDARY + NEW_LINE).getBytes());

            // モデル名
            baos.write((REQUEST_MODEL_NAME_HEADER).getBytes());
            baos.write(("food" + NEW_LINE).getBytes());

            baos.write(("--" + BOUNDARY + NEW_LINE).getBytes());

            // 画像
            //File imageFile = new File(filePath);
            baos.write(convertImageToByte(uri));
            baos.write(convertImageToByte(uri));
            baos.write((NEW_LINE).getBytes());

            baos.write(("--" + BOUNDARY + "--" + NEW_LINE).getBytes());
            baos.flush();
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            baos.close();
        }

        return null;
    }

    private String getBody(Uri uri){
        try{
            byte[] bytes = createRequestBody(uri);
            String base64 = Base64.encodeToString(bytes, Base64.DEFAULT);

            String a = new Gson().toJson(new PostBody("food", base64));
            return a;
        }catch(IOException e){
            e.printStackTrace();
        }

        return null;
    }

    public class PostBody{
        private String image;
        private String modelName;

        public PostBody(String modelName, String image){
            this.image = image;
            this.modelName = modelName;
        }
    }

    private byte[] convertImageToByte(Uri uri){
        byte[] data = null;
        try {
            ContentResolver cr = this.getContentResolver();
            InputStream inputStream = cr.openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            bitmap = resize(bitmap, 100, 100);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 0, baos);
            data = baos.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return data;
    }

    private Bitmap resize(Bitmap picture, int targetWidth, int targetHeight) {
        if (picture == null || height < 0 || width < 0) {
            return null;
        }

        int pictureWidth = picture.getWidth();
        int pictureHeight = picture.getHeight();
        float scale = Math.min((float) targetWidth / pictureWidth, (float) targetHeight / pictureHeight); // (1)

        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);

        return Bitmap.createBitmap(picture, 0, 0, pictureWidth, pictureHeight, matrix, true);
    }
}
