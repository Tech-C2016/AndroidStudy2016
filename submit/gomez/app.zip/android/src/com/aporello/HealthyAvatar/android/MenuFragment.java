package com.aporello.HealthyAvatar.android;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yuki on 16/08/09.
 */
public class MenuFragment extends Fragment{
    private final static String TAG = MenuFragment.class.getSimpleName();

    @BindView(R.id.linear_layout) public View linearLayout;
    @OnClick(R.id.image_view_healthy_score)
    public void clickedHealthyScore(){
        startActivity(new Intent(getActivity(), HealthScoreActivity.class));
    }

    @OnClick(R.id.image_view_setting)
    public void c(){
        startActivity(new Intent(getActivity(), MealEvaluateActivity.class));
    }

    public MenuFragment(){}

    public static MenuFragment getInstance(){
        return new MenuFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_menu, null);
        ButterKnife.bind(this, v);

        linearLayout.setOnClickListener(null);

        return v;
    }
}
