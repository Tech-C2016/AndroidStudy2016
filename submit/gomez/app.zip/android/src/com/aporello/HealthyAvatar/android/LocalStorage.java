package com.aporello.HealthyAvatar.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by N1cK0 on 16/08/09.
 */
public class LocalStorage extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Login.db";
    private static final String TABLE_USER = "user";
    private static final String ID = "_id";
    private static final String CATEGORY = "category";
    private static final String USER_PASSWORD = "password";
    private static final String USER_NAME = "name";
    private static final String USER_EMAIL = "email";
    Context context;

    private static final String TABLE_USER_CREATE
            = "CREATE TABLE " + TABLE_USER
            + " (" + ID + " INTEGER PRIMARY KEY, "
            + CATEGORY + " INT(1), "
            + USER_PASSWORD + " VARCHAR(25), "
            + USER_NAME + " VARCHAR(25),"
            + USER_EMAIL + " VARCHAR(255));";

    private static final String TABLE_USER_DROP =
            "DROP TABLE IF EXISTS "
                    + TABLE_USER;

    public LocalStorage(Context context){
        super(context,DATABASE_NAME,null,1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_USER_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(TABLE_USER_DROP);
        onCreate(db);
    }

    public void insertUser(String password, String email){
        long rowID = -1;
        try{
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(USER_PASSWORD,password);
            values.put(USER_EMAIL,email);
            values.put(ID,1);
            rowID=db.insert(TABLE_USER,null,values);
            db.close();
        } catch (SQLiteException e){
            Log.e ("error",e.toString());
        } finally {
            Log.d("LocalStorage ="," "+rowID);
        }
    }

    public void modifyUser(int category,String name){
        long rowID = -1;
        try{
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(USER_NAME,name);
            values.put(CATEGORY,category);
            rowID=db.update(TABLE_USER,values,ID+"=1",null);
            db.close();
        } catch (SQLiteException e){
            Log.e ("error",e.toString());
        } finally {
            Log.d("LocalStorage ="," "+rowID);
        }
    }

    public void deleteUser(){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_USER, "_id=1",null);
        db.close();
    }

    public String getEmail(){
        SQLiteDatabase db = getReadableDatabase();
        String[] values = {USER_EMAIL,USER_PASSWORD};
        Cursor c = db.query(TABLE_USER,values,"_id=1",null,null,null,null);
        if(c != null){
            c.moveToFirst();
            return c.getString(0);
        }else return null;
    }

    public String getName(){
        SQLiteDatabase db = getReadableDatabase();
        String[] values = {USER_NAME,USER_PASSWORD};
        Cursor c = db.query(TABLE_USER,values,"_id=1",null,null,null,null);
        if(c != null){
            c.moveToFirst();
            return c.getString(0);
        }else return null;
    }

    public String getCategory(){
        SQLiteDatabase db = getReadableDatabase();
        String[] values = {CATEGORY,USER_PASSWORD};
        Cursor c = db.query(TABLE_USER,values,"_id=1",null,null,null,null);
        if(c != null){
            c.moveToFirst();
            return c.getString(0);
        }else return null;
    }

    public String getPassword(){
        SQLiteDatabase db = getReadableDatabase();
        String[] values = {USER_EMAIL,USER_PASSWORD};
        Cursor c = db.query(TABLE_USER,values,"_id=1",null,null,null,null);
        if(c != null){
            c.moveToFirst();
            return c.getString(1);
        }else return null;
    }


    public Cursor getUsers(){
        SQLiteDatabase db = getReadableDatabase();
        String[] values = {USER_EMAIL,USER_PASSWORD};
        Cursor c = db.query(TABLE_USER,values,"_id=1",null,null,null,null);
        if(c != null) {
            c.moveToFirst();
        }
        db.close();
        c.close();
        return c;
    }
}

