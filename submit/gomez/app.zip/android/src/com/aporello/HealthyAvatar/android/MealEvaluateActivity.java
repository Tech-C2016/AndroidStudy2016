package com.aporello.HealthyAvatar.android;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.SeekBar;
import android.widget.Toast;

import com.aporello.HealthyAvatar.android.network.PostNutritionistEvaluateHelper;
import com.google.gson.Gson;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yuki on 16/08/09.
 */
public class MealEvaluateActivity extends AppCompatActivity{
    private final static String TAG = MealEvaluateActivity.class.getSimpleName();

    @BindView(R.id.seek_bar_1) SeekBar seekBarProtein;
    @BindView(R.id.seek_bar_2) SeekBar seekBarLipid;
    @BindView(R.id.seek_bar_3) SeekBar seekBarCarbohydrate;
    @BindView(R.id.seek_bar_4) SeekBar seekBarDairyProduct;
    @BindView(R.id.seek_bar_5) SeekBar seekBarFruit;
    @OnClick(R.id.text_view_send)
    public void clicked(){
        Toast.makeText(this, "送信されました", Toast.LENGTH_SHORT).show();
        Evaluates evaluate = new Evaluates(
                String.valueOf(seekBarProtein.getProgress()),
                String.valueOf(seekBarLipid.getProgress()),
                String.valueOf(seekBarCarbohydrate.getProgress()),
                String.valueOf(seekBarDairyProduct.getProgress()),
                String.valueOf(seekBarFruit.getProgress()));
//        PostNutritionistEvaluateHelper helper = new PostNutritionistEvaluateHelper(this);
//        helper.execute("user", "password", new Gson().toJson(evaluate));
        finish();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        initView();
    }

    private void initView(){
        setContentView(R.layout.activity_meal_evaluate);
        ButterKnife.bind(this);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.app_name) + " for Nutritionist");

        seekBarProtein.setMax(5);
        seekBarLipid.setMax(5);
        seekBarCarbohydrate.setMax(5);
        seekBarDairyProduct.setMax(5);
        seekBarFruit.setMax(5);
    }

    private class Evaluates{
        private String protein;
        private String lipid;
        private String carbohydrate;
        private String dairyProduct;
        private String fruits;

        public Evaluates(String protein, String lipid, String carbohydrate, String dairy_product, String fruit){
            this.protein = protein;
            this.lipid = lipid;
            this.carbohydrate = carbohydrate;
            this.dairyProduct = dairy_product;
            this.fruits = fruit;
        }
    }
}
