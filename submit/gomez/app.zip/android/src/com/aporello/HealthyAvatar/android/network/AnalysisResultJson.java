package com.aporello.HealthyAvatar.android.network;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 画像認識結果のJSON解析用クラス.
 */
public class AnalysisResultJson extends JSONObject{
    /**
     * コンストラクタ.
     *
     * @param json 画像認識結果のJSON
     * @throws JSONException JSON読み込み時にエラーが発生した場合
     */
    public AnalysisResultJson(String json) throws JSONException{
        super(json);
    }

    /**
     * JobIdの取得.
     *
     * @return JobIdを返す
     */
    public String getJobId() {
        return optString("jobId");
    }

    /**
     * 認識結果候補の取得(画像1枚分の結果).
     *
     * @return 画像認識結果の候補を返す
     */
    public List<CandidatesObject> getTopImageCandidates() {
        ArrayList<CandidatesObject> candidates = new ArrayList<CandidatesObject>();

        try {
            JSONArray jsonCandidates = getJSONArray("candidates");

            // JsonからCandidatesObjを作成する
            for (int i = 0; i < jsonCandidates.length(); i++) {
                JSONObject jsonCandidate = jsonCandidates.getJSONObject(i);

                CandidatesObject candidate = new CandidatesObject();
                candidate.mScore = jsonCandidate.getDouble("score");
                candidate.mTag = jsonCandidate.getString("tag");

                candidates.add(candidate);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return candidates;
    }
}
