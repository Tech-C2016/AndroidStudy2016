package com.aporello.HealthyAvatar.android;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by yuki on 16/08/10.
 */
public class ScreenShotActivity extends AppCompatActivity{
    private final static String TAG = ScreenShotActivity.class.getSimpleName();

    @OnClick(R.id.image_view_home)
    public void onClick(){
        startActivity(new Intent(this, MenuFragmentTestActivity.class));
        finish();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_shot);
        ButterKnife.bind(this);
    }
}
