package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by yuki on 16/08/07.
 */
public class PostAsyncTaskLoader extends AsyncTaskLoader<String>{
    private final static String TAG = PostAsyncTaskLoader.class.getSimpleName();

    private String url;
    private String body;

    public PostAsyncTaskLoader(Context context, String url, String body){
        super(context);
        this.url = url;
        this.body = body;
        Log.d(TAG, url);
        Log.d(TAG, body);
    }

    @Override
    public String loadInBackground(){
        StringBuilder builder = new StringBuilder();
        try{
            URL url = new URL(this.url);
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();

            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "multipart/form-data");

            connection.connect();

            PrintWriter writer = new PrintWriter(connection.getOutputStream());

            writer.print(body);

            writer.close();

            InputStream inputStream;
            BufferedReader bufferedReader;
            try{
                inputStream = connection.getInputStream();
            }catch(Exception e){
                inputStream = connection.getErrorStream();
            }
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF8"));

            String line;
            while((line = bufferedReader.readLine()) != null){
                builder.append(line);
            }

            bufferedReader.close();
            connection.disconnect();

        }catch(MalformedURLException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }

        return builder.toString();
    }
}
