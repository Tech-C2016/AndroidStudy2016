package com.aporello.HealthyAvatar.android.network;

/**
 * 画像認識結果データクラス.
 */
public class CandidatesObject{
    /**
     * 認識結果のカテゴリ名.
     */
    public String mTag;

    /**
     * 認識結果に対するスコア.
     */
    public double mScore;
}
