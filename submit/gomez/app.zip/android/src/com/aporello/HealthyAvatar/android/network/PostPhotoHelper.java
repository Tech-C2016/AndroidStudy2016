package com.aporello.HealthyAvatar.android.network;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.util.Log;

/**
 * Created by yuki on 16/08/10.
 */
public class PostPhotoHelper implements LoaderManager.LoaderCallbacks<String>{
    private final static String TAG = PostPhotoHelper.class.getSimpleName();

    private Context context;

    public PostPhotoHelper(Context context){
        this.context = context;
    }

    public void execute(String url, String body){
        Bundle args = new Bundle();
        args.putString("url", url);
        args.putString("body", body);
        ((FragmentActivity)context).getSupportLoaderManager().restartLoader(0, args, this);
    }

    @Override
    public Loader<String> onCreateLoader(int i, Bundle bundle){
        AsyncTaskLoader asyncTaskLoader = new PostAsyncTaskLoader(context, bundle.getString("url"), bundle.getString("body"));
        asyncTaskLoader.forceLoad();
        return asyncTaskLoader;
    }

    @Override
    public void onLoaderReset(Loader<String> loader){

    }

    @Override
    public void onLoadFinished(Loader<String> loader, String s){
        String message;
        if(s != null){
            message = s;
        }else{
            message = "null";
        }

        Log.d(TAG, message);
    }
}
